package fr.o80.korge.jump.scene.level

import com.soywiz.klock.*
import com.soywiz.klock.max
import com.soywiz.korev.*
import com.soywiz.korge.box2d.*
import com.soywiz.korge.input.*
import com.soywiz.korge.scene.*
import com.soywiz.korge.view.*
import com.soywiz.korge.view.tween.*
import com.soywiz.korim.color.*
import kotlinx.coroutines.*
import org.jbox2d.common.*
import org.jbox2d.dynamics.*
import kotlin.math.*

class LevelScene : Scene() {

    private var perso: SolidRect? = null

    override suspend fun SContainer.sceneMain() {
        text("Level") {
            centerXOnStage()
        }
        worldView {
            position(300, 300).scale(1.5)

            perso = solidRect(10, 15, Colors.BLUE)
                .anchor(.5, .5)
                .position(20, -150)
                .registerBodyWithFixture(
                    type = BodyType.DYNAMIC,
                    friction = 0,
                    density = 1,
                    fixedRotation = true,
                    restitution = 0,
                    gravityScale = 2f
                )

            solidRect(1000, 10, Colors.DARKGRAY)
                .anchor(.5, .5)
                .position(0, -10)
                .registerBodyWithFixture(
                    type = BodyType.STATIC,
                    friction = 0,
                    density = 1,
                    restitution = 0
                )

            solidRect(100, 10, Colors.DARKGRAY)
                .anchor(.5, .5)
                .position(-150, -40)
                .registerBodyWithFixture(
                    type = BodyType.STATIC,
                    friction = 0,
                    density = 1,
                    restitution = 0
                )

            solidRect(100, 10, Colors.DARKGRAY)
                .anchor(.5, .5)
                .position(-200, -70)
                .registerBodyWithFixture(
                    type = BodyType.STATIC,
                    friction = 0,
                    density = 1,
                    restitution = 0
                )

            solidRect(10, 1000, Colors.DARKGRAY)
                .anchor(.5, .5)
                .position(-290, -150)
                .registerBodyWithFixture(
                    type = BodyType.STATIC,
                    friction = 0,
                    density = 1,
                    restitution = 0
                )

            solidRect(10, 1000, Colors.DARKGRAY)
                .anchor(.5, .5)
                .position(290, -150)
                .registerBodyWithFixture(
                    type = BodyType.STATIC,
                    friction = 0,
                    density = 1,
                    restitution = 0
                )
        }
    }

    // https://www.iforce2d.net/b2dtut/jumping
    // https://www.iforce2d.net/b2dtut/constant-speed

    private var jumpForce: Float = 9f//6f
    private var maxSpeed: Float = 5f
    private var acceleration: Float = .2f
    private var deceleration: Float = .08f

    private var moveState: MoveState = MoveState.STOP

    override suspend fun SContainer.sceneInit() {
        keys {
            justDown(Key.SPACE) {
                launch {
                    println("Jump")
                    perso?.body?.let { body ->
                        val impulse = body.getMass() * jumpForce
                        body.applyLinearImpulse(Vec2(0f, -impulse), body.worldCenter, true)
                    } ?: error("no body")
                }
            }
            justDown(Key.LEFT) {
                moveState = MoveState.LEFT
            }
            justDown(Key.RIGHT) {
                moveState = MoveState.RIGHT
            }

            addFixedUpdater(60.timesPerSecond) {
                val body = perso?.body ?: return@addFixedUpdater
                if (!views.keys.pressing(Key.LEFT) && !views.keys.pressing(Key.RIGHT)) {
                    moveState = MoveState.STOP
                }

                val currentVelocity = body.linearVelocityX ?: 0f

                val desiredVelocity = when (moveState) {
                    MoveState.STOP -> currentVelocity * (1 - deceleration)
                    MoveState.LEFT -> max(-maxSpeed, currentVelocity - acceleration)
                    MoveState.RIGHT -> min(maxSpeed, currentVelocity + acceleration)
                }

                val velocityChange = desiredVelocity - currentVelocity
                val impulse = body.getMass() * velocityChange

                body.applyLinearImpulse(Vec2(impulse, 0f), body.worldCenter, true)
            }
        }
    }
}

enum class MoveState {
    STOP,
    LEFT,
    RIGHT
}
/*
    private var jumpForce: Float = 6f
    private var maxSpeed: Float = 5f
    private var acceleration: Float = .2f
    private var deceleration: Float = .08f

    private var moveState: MoveState = MoveState.STOP

    override suspend fun SContainer.sceneInit() {
        keys {
            justDown(Key.SPACE) {
                launch {
                    println("Jump")
                    perso?.body?.let { body ->
                        val impulse = body.getMass() * jumpForce
                        body.applyLinearImpulse(Vec2(0f, -impulse), body.worldCenter, true)
                    } ?: error("no body")
                }
            }
            justDown(Key.LEFT) {
                moveState = MoveState.LEFT
            }
            justDown(Key.RIGHT) {
                moveState = MoveState.RIGHT
            }

            addFixedUpdater(60.timesPerSecond) {
                if (!views.keys.pressing(Key.LEFT) && !views.keys.pressing(Key.RIGHT)) {
                    moveState = MoveState.STOP
                }

                val currentVelocity = perso?.body?.linearVelocityX ?: 0f

                val velocity = when (moveState) {
                    MoveState.STOP -> currentVelocity * (1 - deceleration)
                    MoveState.LEFT -> max(-maxSpeed, currentVelocity - acceleration)
                    MoveState.RIGHT -> min(maxSpeed, currentVelocity + acceleration)
                }
                perso?.body?.linearVelocityX = velocity
            }
        }
    }
}

enum class MoveState {
    STOP,
    LEFT,
    RIGHT
}
*/
