import com.soywiz.korge.*
import fr.o80.korge.jump.*

suspend fun main() = Korge(Korge.Config(module = JumpConfig))
